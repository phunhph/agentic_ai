"""
V3Service — DANN Orchestrator.
Pipeline: Perception → Reasoning → Action → Learning
"""
import re
import time
from v3.neural.brain import NeuralBrain
from v3.neural.synapse import SynapseManager
from v3.neural.learning_matrix import NeuralWeightMatrix
from v2.contracts import ExecutionPlan, RequestFilter
from v2.execute import execute_plan


class V3Service:
    def __init__(self):
        self.brain = NeuralBrain()
        self.synapse = SynapseManager()
        self.matrix = NeuralWeightMatrix()

    def run(self, query: str, session_id: str = "default") -> dict:
        start = time.time()

        # ── 1. PERCEPTION ──────────────────────────────────
        weights = self.matrix.get_weights()
        network = self.synapse.get_local_network(query.split(), weights)

        # ── 2. REASONING (Single LLM call) ─────────────────
        activation = self.brain.activate(query, network, weights)

        # ── 3. ACTION ──────────────────────────────────────
        plan = self._build_plan(activation)
        exec_result = execute_plan(plan)
        data = exec_result.data if hasattr(exec_result, "data") else []

        # ── 4. LEARNING ───────────────────────────────────
        entity = activation.get("primary_entity", "unknown")
        self.matrix.reinforce(entity, success=len(data) > 0)

        # ── 5. RESPONSE ───────────────────────────────────
        conclusion = activation.get("conclusion_template", "")
        if conclusion:
            # Regex lọc sạch mọi placeholder {xxx} → thay bằng số thực
            conclusion = re.sub(r"\{.*?\}", str(len(data)), conclusion)

        if not conclusion or len(conclusion) < 5:
            if data:
                conclusion = f"Dạ, Cindy đã tìm thấy {len(data)} kết quả cho yêu cầu '{query}' của bạn ạ. Mời bạn xem chi tiết bên dưới nhé!"
            else:
                conclusion = f"Dạ, Cindy đã tìm kiếm nhưng chưa thấy kết quả nào cho '{query}'. Bạn có muốn thử từ khóa khác không ạ?"

        latency = int((time.time() - start) * 1000)
        thought = activation.get("thought", "")

        return {
            "query": query,
            "data": data,
            "assistant_response": conclusion,
            # Các trường UI cần
            "resolved_query": query,
            "intent": activation.get("intent", "retrieve"),
            "primary_entity": entity,
            "thought_process": thought,
            "reflection": thought,  # UI cần trường này
            "execution_result": data,  # UI đọc trường này cho JSON panel
            "latency_ms": latency,
        }

    def _build_plan(self, activation: dict) -> ExecutionPlan:
        """Chuyển kết quả suy luận thành ExecutionPlan."""
        entity = activation.get("primary_entity", "hbl_account")

        # Filters
        raw_filters = activation.get("filters", [])
        filters = []
        for f in raw_filters:
            if not isinstance(f, dict):
                continue
            field = f.get("field")
            if not field:
                continue
            # Prefix field với table name nếu chưa có
            if "." not in field:
                field = f"{entity}.{field}"
            filters.append(RequestFilter(
                field=field,
                op=f.get("op", "eq"),
                value=f.get("value")
            ))

        # Aggregate ops — format phải khớp với runtime engine
        intent = activation.get("intent", "retrieve")
        aggregate_ops = []
        if intent == "analyze":
            aggregate_ops.append({
                "type": "count",       # runtime đọc "type", KHÔNG phải "op"
                "table": entity,       # runtime CẦN "table"
                "alias": "total_count"
            })

        return ExecutionPlan(
            root_table=entity,
            where_filters=filters,
            aggregate_ops=aggregate_ops,
            limit=20,
        )

    # ── PUBLIC API ─────────────────────────────────────
    def run_pipeline(self, query: str, session_id: str = "default", role: str = "DEFAULT") -> dict:
        try:
            result = self.run(query, session_id)
            return {
                "ok": True,
                "assistant_response": result["assistant_response"],
                "data": result["data"],
                "resolved_query": result["resolved_query"],
                "execution_result": result["execution_result"],
                "reasoning": result,
                "latency_ms": result["latency_ms"],
            }
        except Exception as e:
            return {
                "ok": False,
                "assistant_response": f"Lỗi hệ thống DANN: {str(e)}",
                "data": [],
                "latency_ms": 0,
            }
