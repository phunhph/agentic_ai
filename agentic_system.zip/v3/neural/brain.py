"""
NeuralBrain — Bộ não DANN.
Thực hiện suy luận 1 lần duy nhất (single-pass) với Chain-of-Thought nội tại.
Output: JSON chứa cả plan lẫn conclusion bằng tiếng Việt.
"""
import json
import datetime
from infra.settings import OLLAMA_REASONING_MODEL
import ollama


class NeuralBrain:
    def __init__(self, model: str = OLLAMA_REASONING_MODEL):
        self.model = model

    def activate(self, query: str, schema_graph: dict, weights: dict) -> dict:
        """
        Single-pass DANN Activation.
        Input: query + weighted schema + historical weights.
        Output: {primary_entity, filters, intent, thought, conclusion}
        """
        now = datetime.datetime.now().strftime("%Y-%m-%d")

        # Lấy top 3 đường dẫn mạnh nhất làm kinh nghiệm
        top_paths = sorted(weights.items(), key=lambda x: x[1], reverse=True)[:3]
        experience_str = ", ".join([f"{k}({v:.1f})" for k, v in top_paths]) if top_paths else "Chưa có"

        prompt = f"""[DANN CORE - {now}]

SCHEMA (Weighted):
{json.dumps(schema_graph, ensure_ascii=False)}

KINH NGHIỆM: {experience_str}

YÊU CẦU: {query}

BẠN LÀ BỘ NÃO DANN. Hãy suy nghĩ theo 3 bước:
1. XÁC ĐỊNH THỰC THỂ: Chọn bảng chính từ SCHEMA.entities (VD: hbl_contract, hbl_lead).
2. TRÍCH XUẤT BỘ LỌC: Lấy các giá trị lọc NGUYÊN BẢN từ câu hỏi.
3. KẾT LUẬN: Viết câu trả lời tiếng Việt lễ phép. TUYỆT ĐỐI KHÔNG tự bịa số liệu. Chỉ được dùng đúng MỘT biến duy nhất là {{count}} nếu cần báo số lượng. KHÔNG dùng {{count_1}}, {{count_2}}, v.v.

TRẢ VỀ JSON:
{{
  "primary_entity": "tên_bảng",
  "intent": "retrieve|analyze",
  "filters": [{{"field": "tên_cột", "op": "eq|contains|range", "value": "giá_trị"}}],
  "thought": "Giải thích ngắn gọn bằng tiếng Việt",
  "conclusion_template": "Dạ, Cindy đã tìm thấy {{count}} kết quả phù hợp..."
}}
"""
        try:
            response = ollama.generate(
                model=self.model,
                prompt=prompt,
                format="json",
                stream=False,
                options={"num_predict": 400, "temperature": 0.1}
            )
            result = json.loads(response["response"])

            # Validation: đảm bảo primary_entity tồn tại trong schema
            entities = schema_graph.get("entities", {})
            if result.get("primary_entity") not in entities and entities:
                # Auto-correct: chọn entity đầu tiên trong schema
                result["primary_entity"] = list(entities.keys())[0]

            return result
        except Exception as e:
            return {
                "primary_entity": "hbl_account",
                "intent": "retrieve",
                "filters": [],
                "thought": f"Lỗi kích hoạt nơ-ron: {str(e)}",
                "conclusion_template": "Xin lỗi, Cindy gặp sự cố khi xử lý yêu cầu."
            }
