"""
SynapseManager — Quản lý đồ thị nơ-ron DANN.
Tạo weighted sub-graph từ MetadataProvider + NeuralWeightMatrix.
"""
from v2.metadata import MetadataProvider


class SynapseManager:
    """
    Xây dựng đồ thị nơ-ron có trọng số từ schema (db.json).
    Mỗi entity là một nơ-ron, mỗi lookup relation là một khớp thần kinh.
    """
    def __init__(self):
        self.provider = MetadataProvider()

    def get_local_network(self, keywords: list[str], weights: dict) -> dict:
        """
        Trả về sub-graph liên quan đến câu hỏi.
        Mỗi entity có synaptic_strength dựa trên lịch sử thành công.
        """
        # Detect entities từ keywords
        detected = set()
        for kw in keywords:
            table = self.provider.get_table_by_alias(kw)
            if table:
                detected.add(table)

        # Fallback nếu không detect được entity nào
        if not detected:
            detected = {"hbl_account", "hbl_contract", "hbl_opportunities", "hbl_lead"}

        # Build weighted graph
        network = {"entities": {}, "synapses": []}

        for table in detected:
            if not self.provider.is_valid_table(table):
                continue

            strength = weights.get(table, 0.0)
            fields = list(self.provider.get_fields(table))

            network["entities"][table] = {
                "fields": fields[:10],
                "strength": round(strength, 2)
            }

        # Thêm synapses (edges) giữa các entities đã detect
        for from_t, to_t in self.provider.metadata.lookup_edges:
            if from_t in detected or to_t in detected:
                network["synapses"].append({
                    "from": from_t,
                    "to": to_t,
                    "weight": round(weights.get(f"{from_t}->{to_t}", 0.0), 2)
                })

        return network
